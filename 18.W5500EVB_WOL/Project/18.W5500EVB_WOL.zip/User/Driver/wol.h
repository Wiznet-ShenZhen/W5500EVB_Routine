#ifndef	_WOL_H_
#define	_WOL_H_


void do_wol(void);

#endif
/* _WOL_H_ */
