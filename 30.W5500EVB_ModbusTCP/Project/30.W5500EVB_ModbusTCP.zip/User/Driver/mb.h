#ifndef _MB_H_
#define _MB_H_

void mbTCPtoRTU(void);
void mbRTUtoTCP(void);
void mbASCIItoTCP(void);
void mbTCPtoASCII(void);
#endif

