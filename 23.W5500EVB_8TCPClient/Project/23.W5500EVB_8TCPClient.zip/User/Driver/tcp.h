#ifndef _TCP_H_
#define _TCP_H_

#include "usart.h"
#include "ult.h"
#include "socket.h"
#include "w5500.h"
#include <string.h>

void tcpc(uint8 i);
void do_8tcpc(void);

#endif  /*  _TCP_H_  */
