#ifndef _TCP_H_

#define _TCP_H_

void tcpc(void);


#endif
